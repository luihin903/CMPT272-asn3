export enum GreyBreeds {
    NotGrey,
    LessGrey,
    NormalGrey,
    MoreGrey,
    SuperGrey
}

export enum ChestnutBreeds {
    NotChestnut,
    LessChestnut,
    NormalChestnut,
    MoreChestnut,
    SuperChestnut
}

export enum WhiteBreeds {
    NotWhite,
    LessWhite,
    NormalWhite,
    MoreWhite,
    SuperWhite
}

export enum BlackBreeds {
    NotBlack,
    LessBlack,
    NormalBlack,
    MoreBlack,
    SuperBlack
}