System.register(["../Pig"], function (exports_1, context_1) {
    "use strict";
    var Pig_1, GreyPig;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Pig_1_1) {
                Pig_1 = Pig_1_1;
            }
        ],
        execute: function () {
            GreyPig = class GreyPig extends Pig_1.Pig {
                constructor(swimming, breed, name, height, weight, personality) {
                    super(name, height, weight, personality);
                    this.category = "Grey";
                    this.swimming = swimming;
                    this.breed = breed;
                }
            };
            exports_1("GreyPig", GreyPig);
        }
    };
});
