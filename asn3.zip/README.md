CMPT 272 asn3

Hin Lui 301571436

How to use:
    lite-server