export interface Animal {
    name: string;
    height: number;
    weight: number;
    personality: string;
}